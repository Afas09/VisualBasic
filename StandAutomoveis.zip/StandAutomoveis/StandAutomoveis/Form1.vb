﻿Public Class Form1
    Public frmSobre As FormSobre
    Public frmAjuda As FormAjuda
    Public frmMarcas As FormMarcas
    Public frmModelos As FormModelos
    Public frmViaturas As FormViaturas
    Private Sub MenuSobre_Click(sender As Object, e As EventArgs) Handles MenuSobre.Click
        If IsNothing(frmSobre) = False Then
        Else
            frmSobre = New FormSobre()
            frmSobre.MdiParent = Me
            frmSobre.Show()
        End If
    End Sub
    Private Sub MenuSair_Click(sender As Object, e As EventArgs) Handles MenuSair.Click
        Me.Close()
        Application.Exit()
    End Sub

    Private Sub MenuAjuda_Click(sender As Object, e As EventArgs) Handles MenuAjuda.Click
        If IsNothing(frmAjuda) = False Then
        Else
            frmAjuda = New FormAjuda()
            frmAjuda.MdiParent = Me
            frmAjuda.Show()
        End If
    End Sub

    Private Sub MenuMarcas_Click(sender As Object, e As EventArgs) Handles MenuMarcas.Click
        If IsNothing(frmMarcas) = False Then
        Else
            frmMarcas = New FormMarcas()
            frmMarcas.MdiParent = Me
            frmMarcas.Show()
        End If
    End Sub

    Private Sub MenuModelos_Click(sender As Object, e As EventArgs) Handles MenuModelos.Click
        If IsNothing(frmModelos) = False Then
        Else
            frmModelos = New FormModelos()
            frmModelos.MdiParent = Me
            frmModelos.Show()
        End If
    End Sub

    Private Sub MenuViaturas_Click(sender As Object, e As EventArgs) Handles MenuViaturas.Click
        If IsNothing(frmViaturas) = False Then
        Else
            frmViaturas = New FormViaturas()
            frmViaturas.MdiParent = Me
            frmViaturas.Show()
        End If
    End Sub

    Public Sub Mensagem(txt As String)
        MessageBox.Show(txt)
    End Sub
End Class
