﻿Public Class FormViaturas
    Private Sub FormViaturas_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Form1.frmViaturas = Nothing
    End Sub
End Class