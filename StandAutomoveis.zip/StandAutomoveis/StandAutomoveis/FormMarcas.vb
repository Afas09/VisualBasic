﻿Public Class FormMarcas
    Private Sub FormMarcas_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Form1.frmMarcas = Nothing
    End Sub
End Class