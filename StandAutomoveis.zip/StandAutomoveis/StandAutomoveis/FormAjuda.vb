﻿Public Class FormAjuda
    Private Sub FormAjuda_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Form1.frmAjuda = Nothing
    End Sub
End Class