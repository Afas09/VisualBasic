﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        MenuStrip1 = New MenuStrip()
        AbrirFormToolStripMenuItem = New ToolStripMenuItem()
        MenuSobre = New ToolStripMenuItem()
        MenuSair = New ToolStripMenuItem()
        ViaturasToolStripMenuItem = New ToolStripMenuItem()
        MenuMarcas = New ToolStripMenuItem()
        MenuModelos = New ToolStripMenuItem()
        MenuViaturas = New ToolStripMenuItem()
        MenuAjuda = New ToolStripMenuItem()
        MenuStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' MenuStrip1
        ' 
        MenuStrip1.Items.AddRange(New ToolStripItem() {AbrirFormToolStripMenuItem, ViaturasToolStripMenuItem, MenuAjuda})
        MenuStrip1.Location = New Point(0, 0)
        MenuStrip1.Name = "MenuStrip1"
        MenuStrip1.Size = New Size(800, 24)
        MenuStrip1.TabIndex = 1
        MenuStrip1.Text = "Arquivo"
        ' 
        ' AbrirFormToolStripMenuItem
        ' 
        AbrirFormToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {MenuSobre, MenuSair})
        AbrirFormToolStripMenuItem.Name = "AbrirFormToolStripMenuItem"
        AbrirFormToolStripMenuItem.Size = New Size(76, 20)
        AbrirFormToolStripMenuItem.Text = "Aplicações"
        ' 
        ' MenuSobre
        ' 
        MenuSobre.Name = "MenuSobre"
        MenuSobre.Size = New Size(104, 22)
        MenuSobre.Text = "Sobre"
        ' 
        ' MenuSair
        ' 
        MenuSair.Name = "MenuSair"
        MenuSair.Size = New Size(104, 22)
        MenuSair.Text = "Sair"
        ' 
        ' ViaturasToolStripMenuItem
        ' 
        ViaturasToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {MenuMarcas, MenuModelos, MenuViaturas})
        ViaturasToolStripMenuItem.Name = "ViaturasToolStripMenuItem"
        ViaturasToolStripMenuItem.Size = New Size(61, 20)
        ViaturasToolStripMenuItem.Text = "Viaturas"
        ' 
        ' MenuMarcas
        ' 
        MenuMarcas.Name = "MenuMarcas"
        MenuMarcas.Size = New Size(180, 22)
        MenuMarcas.Text = "Marcas"
        ' 
        ' MenuModelos
        ' 
        MenuModelos.Name = "MenuModelos"
        MenuModelos.Size = New Size(180, 22)
        MenuModelos.Text = "Modelos"
        ' 
        ' MenuViaturas
        ' 
        MenuViaturas.Name = "MenuViaturas"
        MenuViaturas.Size = New Size(180, 22)
        MenuViaturas.Text = "Viaturas"
        ' 
        ' MenuAjuda
        ' 
        MenuAjuda.Name = "MenuAjuda"
        MenuAjuda.Size = New Size(50, 20)
        MenuAjuda.Text = "Ajuda"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(MenuStrip1)
        IsMdiContainer = True
        MainMenuStrip = MenuStrip1
        Name = "Form1"
        Text = "STAND DE AUTOMÓVEIS"
        WindowState = FormWindowState.Maximized
        MenuStrip1.ResumeLayout(False)
        MenuStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents AbrirFormToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenuSobre As ToolStripMenuItem
    Friend WithEvents MenuSair As ToolStripMenuItem
    Friend WithEvents ViaturasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenuMarcas As ToolStripMenuItem
    Friend WithEvents MenuModelos As ToolStripMenuItem
    Friend WithEvents MenuViaturas As ToolStripMenuItem
    Friend WithEvents MenuAjuda As ToolStripMenuItem

End Class
