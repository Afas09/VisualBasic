﻿Public Class FormModelos
    Private Sub FormModelos_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Form1.frmModelos = Nothing
    End Sub
End Class