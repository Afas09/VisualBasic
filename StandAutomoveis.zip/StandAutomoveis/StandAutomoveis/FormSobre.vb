﻿Public Class FormSobre
    Private Sub FormSobre_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Form1.frmSobre = Nothing
    End Sub

    Private Sub FormSobre_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form1.Mensagem("Olá mi bro! Bem vindo ao Reinozadas dos kebabastics")
    End Sub
End Class