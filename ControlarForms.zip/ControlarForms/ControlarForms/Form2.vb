﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.frm2 = Nothing
        Form1.Show()
        Me.Close()   ' este comando faz com que o Form2 se feche mas o Form1 não sabe que este foi fechado e se não o informarmos vai dar a mensagem que já está aberto
    End Sub
End Class