﻿Public Class Form1
    Public frm2 As Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If IsNothing(frm2) = False Then

            'o formulário esta ativo

            MsgBox("O formulário já esta aberto !", MsgBoxStyle.Exclamation)

        Else

            frm2 = New Form2()

            frm2.Show()

            Me.Hide()   ' esconde-me .. também podia ser apenas Hide() sem o Me.
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'Close()  ' Close ou Me.Close  fecha o Form1 que é o nosso 'Main' 

        Application.Exit() ' este fecha a App Toda
    End Sub
End Class
